enableActionClickSidePanel();

chrome.runtime.onInstalled.addListener(() => {
  enableActionClickSidePanel();
});

chrome.action.onClicked.addListener(async (tab) => {
  try {
    await chrome.sidePanel.open({ tabId: tab.id });
  } catch (err) {
    chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true }).catch(() => {});
  }
});

function enableActionClickSidePanel() {
  if (!chrome.sidePanel || !chrome.sidePanel.setPanelBehavior) return;
  chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true }).catch(() => {});
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  handleMessage(message, sender).then(sendResponse).catch(err => {
    sendResponse({ success: false, error: err.message });
  });
  return true;
});

async function handleMessage(message, sender) {
  switch (message.type) {
    case 'CHECK_PAGE':
      return await handleCheckPage();
    case 'EXTRACT_MEDIA':
      return await handleExtractMedia();
    case 'DOWNLOAD':
      return await handleDownload(message.payload);
    default:
      throw new Error(`未知消息类型: ${message.type}`);
  }
}

async function handleCheckPage() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab || !tab.url) {
    return { success: true, data: { supported: false, reason: '无法获取当前标签页' } };
  }

  const url = new URL(tab.url);
  const host = url.hostname;
  const isSupportedHostValue = isSupportedHost(host);
  const supported = isSupportedHostValue && isProductPageUrl(url);

  return {
    success: true,
    data: {
      supported,
      isSupportedHost: isSupportedHostValue,
      url: tab.url,
      title: tab.title,
      host: host
    }
  };
}

async function handleExtractMedia() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

  if (!tab || !tab.url) {
    throw new Error('无法获取当前标签页信息');
  }

  const url = new URL(tab.url);
  const host = url.hostname;
  if (!isSupportedHost(host) || !isProductPageUrl(url)) {
    throw new Error('请在淘宝或天猫商品页面使用此功能');
  }

  try {
    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      files: ['content/content.js']
    });

    const results = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: () => globalThis.__mediaHelperExtractMedia && globalThis.__mediaHelperExtractMedia()
    });

    if (results && results[0] && results[0].result) {
      return { success: true, data: results[0].result };
    }

    throw new Error('内容脚本执行失败，请刷新页面后重试');
  } catch (err) {
    if (err.message.includes('Cannot access')) {
      throw new Error('请在淘宝/天猫商品详情页使用此功能，部分页面受浏览器限制无法访问');
    }
    throw err;
  }
}

async function handleDownload(payload) {
  const { url, filename } = payload;

  if (!url) {
    throw new Error('下载链接不能为空');
  }

  try {
    const id = await chrome.downloads.download({
      url: url,
      filename: sanitizeDownloadPath(filename || 'image.jpg'),
      saveAs: false
    });

    return { success: true, data: { downloadId: id } };
  } catch (err) {
    throw new Error(`下载失败: ${err.message}`);
  }
}

function sanitizeDownloadPath(name) {
  return String(name || 'image.jpg')
    .split('/')
    .map(sanitizePathSegment)
    .filter(Boolean)
    .join('/')
    .slice(0, 240) || 'image.jpg';
}

function sanitizePathSegment(segment) {
  const cleaned = String(segment || '')
    .replace(/[<>:"\\|?*]/g, '_')
    .replace(/\s+/g, '_')
    .replace(/\.+$/g, '')
    .slice(0, 80);

  if (!cleaned || cleaned === '.' || cleaned === '..') {
    return '_';
  }

  return cleaned;
}

function isSupportedHost(host) {
  const normalizedHost = String(host || '').toLowerCase();
  return normalizedHost === 'taobao.com' ||
    normalizedHost.endsWith('.taobao.com') ||
    normalizedHost === 'tmall.com' ||
    normalizedHost.endsWith('.tmall.com');
}

function isProductPageUrl(url) {
  const host = url.hostname.toLowerCase();
  const pathname = url.pathname.toLowerCase();

  if (host === 'detail.tmall.com' || host.endsWith('.detail.tmall.com')) {
    return pathname.includes('/item.htm') || pathname.includes('/item_o.htm');
  }

  if (host === 'item.taobao.com' || host.endsWith('.item.taobao.com')) {
    return pathname.includes('/item.htm');
  }

  if (host === 'world.taobao.com' || host.endsWith('.world.taobao.com')) {
    return pathname.includes('/item/');
  }

  return false;
}
