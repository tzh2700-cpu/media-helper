Add-Type -AssemblyName System.Drawing

$sizes = @(16, 48, 128)
$outputDir = "c:\Users\pc\skill训练\media-helper\icons"

$bgStart = [System.Drawing.Color]::FromArgb(232, 69, 60)
$bgEnd = [System.Drawing.Color]::FromArgb(192, 57, 43)
$white = [System.Drawing.Color]::White

foreach ($size in $sizes) {
    $bmp = New-Object System.Drawing.Bitmap($size, $size)
    $g = [System.Drawing.Graphics]::FromImage($bmp)
    $g.SmoothingMode = 'HighQuality'

    $rect = New-Object System.Drawing.Rectangle(0, 0, $size, $size)
    $gradientBrush = New-Object System.Drawing.Drawing2D.LinearGradientBrush(
        $rect, $bgStart, $bgEnd,
        [System.Drawing.Drawing2D.LinearGradientMode]::Vertical)
    $g.FillRectangle($gradientBrush, $rect)

    $m = [int]($size * 0.15)
    if ($m -lt 2) { $m = 2 }
    $innerX = $m
    $innerY = $m
    $innerW = $size - 2 * $m
    $innerH = $size - 2 * $m
    $rad = [int]($size * 0.18)
    if ($rad -lt 2) { $rad = 2 }

    $innerBrush = New-Object System.Drawing.SolidBrush($white)
    $path = New-Object System.Drawing.Drawing2D.GraphicsPath
    $path.AddArc($innerX, $innerY, $rad, $rad, 180, 90)
    $path.AddArc($innerX + $innerW - $rad, $innerY, $rad, $rad, 270, 90)
    $path.AddArc($innerX + $innerW - $rad, $innerY + $innerH - $rad, $rad, $rad, 0, 90)
    $path.AddArc($innerX, $innerY + $innerH - $rad, $rad, $rad, 90, 90)
    $path.CloseFigure()
    $g.FillPath($innerBrush, $path)

    $im = [int]($size * 0.25)
    if ($im -lt 3) { $im = 3 }
    $ix = $im
    $iy = $im
    $iw = $size - 2 * $im
    $ih = [int]($iw * 0.65)
    $irad = [int]($size * 0.05)
    if ($irad -lt 1) { $irad = 1 }

    $innerPath = New-Object System.Drawing.Drawing2D.GraphicsPath
    $innerPath.AddArc($ix, $iy, $irad, $irad, 180, 90)
    $innerPath.AddArc($ix + $iw - $irad, $iy, $irad, $irad, 270, 90)
    $innerPath.AddArc($ix + $iw - $irad, $iy + $ih - $irad, $irad, $irad, 0, 90)
    $innerPath.AddArc($ix, $iy + $ih - $irad, $irad, $irad, 90, 90)
    $innerPath.CloseFigure()
    $g.FillPath($gradientBrush, $innerPath)

    $px = [int]($ix + $iw * 0.35)
    $py = [int]($iy + $ih * 0.25)
    $ps = [int]($ih * 0.5)
    $playBrush = New-Object System.Drawing.SolidBrush($white)
    $playPoints = @(
        [System.Drawing.Point]::new($px, $py),
        [System.Drawing.Point]::new($px, $py + $ps),
        [System.Drawing.Point]::new($px + $ps, $py + [int]($ps / 2))
    )
    $g.FillPolygon($playBrush, $playPoints)

    if ($size -ge 48) {
        $arrowY = [int]($iy + $ih + $size * 0.06)
        $arrowX = [int]($ix + $iw * 0.5)
        $penW = [int]($size * 0.04)
        if ($penW -lt 2) { $penW = 2 }
        $arrowPen = New-Object System.Drawing.Pen($bgStart, $penW)
        $arrowPen.StartCap = 'Round'
        $arrowPen.EndCap = 'Round'
        $g.DrawLine($arrowPen, $arrowX - [int]($size * 0.06), $arrowY - [int]($size * 0.06), $arrowX, $arrowY)
        $g.DrawLine($arrowPen, $arrowX, $arrowY, $arrowX + [int]($size * 0.06), $arrowY - [int]($size * 0.06))
        $arrowPen.Dispose()
    }

    $g.Dispose()
    $innerBrush.Dispose()
    $gradientBrush.Dispose()
    $playBrush.Dispose()
    $path.Dispose()
    $innerPath.Dispose()

    $filePath = Join-Path $outputDir "icon$size.png"
    $bmp.Save($filePath, [System.Drawing.Imaging.ImageFormat]::Png)
    $bmp.Dispose()
    Write-Host "Created: $filePath ($($size)x$($size))"
}

Write-Host "All icons generated successfully!"
