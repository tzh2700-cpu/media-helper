Add-Type -AssemblyName System.Drawing

$outDir = Split-Path -Parent $MyInvocation.MyCommand.Path

function Add-RoundedRectPath(
  [System.Drawing.Drawing2D.GraphicsPath]$path,
  [float]$x,
  [float]$y,
  [float]$w,
  [float]$h,
  [float]$r
) {
  $d = $r * 2
  $path.AddArc($x, $y, $d, $d, 180, 90)
  $path.AddArc($x + $w - $d, $y, $d, $d, 270, 90)
  $path.AddArc($x + $w - $d, $y + $h - $d, $d, $d, 0, 90)
  $path.AddArc($x, $y + $h - $d, $d, $d, 90, 90)
  $path.CloseFigure()
}

function New-Point([double]$x, [double]$y, [double]$scale) {
  return [System.Drawing.PointF]::new([float]($x * $scale), [float]($y * $scale))
}

$blue = [System.Drawing.Color]::FromArgb(22, 119, 255)
$cyan = [System.Drawing.Color]::FromArgb(20, 184, 166)
$navy = [System.Drawing.Color]::FromArgb(12, 32, 58)
$white = [System.Drawing.Color]::FromArgb(248, 252, 255)
$green = [System.Drawing.Color]::FromArgb(34, 197, 94)
$dark = [System.Drawing.Color]::FromArgb(15, 23, 42)

foreach ($size in @(16, 48, 128)) {
  $scale = $size / 128.0
  $bmp = [System.Drawing.Bitmap]::new($size, $size)
  $g = [System.Drawing.Graphics]::FromImage($bmp)
  $g.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::AntiAlias
  $g.PixelOffsetMode = [System.Drawing.Drawing2D.PixelOffsetMode]::HighQuality
  $g.Clear([System.Drawing.Color]::Transparent)

  $bgRect = [System.Drawing.RectangleF]::new(0, 0, $size, $size)
  $bgPath = [System.Drawing.Drawing2D.GraphicsPath]::new()
  Add-RoundedRectPath $bgPath 0 0 $size $size ([float](24 * $scale))
  $bgBrush = [System.Drawing.Drawing2D.LinearGradientBrush]::new($bgRect, $blue, $cyan, 45)
  $g.FillPath($bgBrush, $bgPath)

  $whiteBrush = [System.Drawing.SolidBrush]::new($white)
  $greenBrush = [System.Drawing.SolidBrush]::new($green)
  $darkBrush = [System.Drawing.SolidBrush]::new($dark)
  $navyPen = [System.Drawing.Pen]::new($navy, [Math]::Max(1, 5 * $scale))
  $navyPen.LineJoin = [System.Drawing.Drawing2D.LineJoin]::Round

  $cardPath = [System.Drawing.Drawing2D.GraphicsPath]::new()
  Add-RoundedRectPath $cardPath ([float](25 * $scale)) ([float](25 * $scale)) ([float](78 * $scale)) ([float](62 * $scale)) ([float](9 * $scale))
  $g.FillPath($whiteBrush, $cardPath)
  $g.DrawPath($navyPen, $cardPath)

  $mountain = [System.Drawing.Drawing2D.GraphicsPath]::new()
  $mountain.AddPolygon([System.Drawing.PointF[]]@(
    (New-Point 34 74 $scale),
    (New-Point 51 56 $scale),
    (New-Point 64 72 $scale),
    (New-Point 75 61 $scale),
    (New-Point 94 78 $scale)
  ))
  $g.FillPath([System.Drawing.SolidBrush]::new([System.Drawing.Color]::FromArgb(191, 230, 255)), $mountain)
  $g.FillEllipse($greenBrush, [float](76 * $scale), [float](38 * $scale), [float](13 * $scale), [float](13 * $scale))

  $arrowPen = [System.Drawing.Pen]::new($dark, [Math]::Max(2, 9 * $scale))
  $arrowPen.StartCap = [System.Drawing.Drawing2D.LineCap]::Round
  $arrowPen.EndCap = [System.Drawing.Drawing2D.LineCap]::Round
  $g.DrawLine($arrowPen, [float](64 * $scale), [float](72 * $scale), [float](64 * $scale), [float](106 * $scale))

  $head = [System.Drawing.Drawing2D.GraphicsPath]::new()
  $head.AddPolygon([System.Drawing.PointF[]]@(
    (New-Point 45 91 $scale),
    (New-Point 64 111 $scale),
    (New-Point 83 91 $scale)
  ))
  $g.FillPath($darkBrush, $head)

  if ($size -ge 48) {
    $shinePen = [System.Drawing.Pen]::new([System.Drawing.Color]::FromArgb(180, 255, 255, 255), [Math]::Max(1, 4 * $scale))
    $shinePen.StartCap = [System.Drawing.Drawing2D.LineCap]::Round
    $shinePen.EndCap = [System.Drawing.Drawing2D.LineCap]::Round
    $g.DrawLine($shinePen, [float](23 * $scale), [float](18 * $scale), [float](43 * $scale), [float](18 * $scale))
    $shinePen.Dispose()
  }

  $file = Join-Path $outDir "icon$size.png"
  if (Test-Path -LiteralPath $file) {
    Remove-Item -LiteralPath $file -Force
  }
  $bmp.Save($file, [System.Drawing.Imaging.ImageFormat]::Png)

  $bgPath.Dispose()
  $bgBrush.Dispose()
  $whiteBrush.Dispose()
  $greenBrush.Dispose()
  $darkBrush.Dispose()
  $navyPen.Dispose()
  $cardPath.Dispose()
  $mountain.Dispose()
  $arrowPen.Dispose()
  $head.Dispose()
  $g.Dispose()
  $bmp.Dispose()

  Write-Host "Created $file"
}
