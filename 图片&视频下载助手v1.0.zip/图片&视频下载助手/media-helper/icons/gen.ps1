Add-Type -AssemblyName System.Drawing
$dir = "c:\Users\pc\skill训练\media-helper\icons"
$red = [System.Drawing.Color]::FromArgb(232, 69, 60)

foreach ($s in @(16, 48, 128)) {
  $bmp = New-Object System.Drawing.Bitmap($s, $s)
  $g = [System.Drawing.Graphics]::FromImage($bmp)
  $g.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::HighQuality
  $g.Clear($red)
  
  $fs = [System.Drawing.FontStyle]::Bold
  $fontSize = [Math]::Max(8, [int]($s * 0.5))
  $font = New-Object System.Drawing.Font("Segoe UI", $fontSize, $fs)
  $brush = [System.Drawing.Brushes]::White
  
  $rect = New-Object System.Drawing.RectangleF(0, 0, $s, $s)
  $sf = New-Object System.Drawing.StringFormat
  $sf.Alignment = [System.Drawing.StringAlignment]::Center
  $sf.LineAlignment = [System.Drawing.StringAlignment]::Center
  $g.DrawString("M", $font, $brush, $rect, $sf)
  
  $g.Dispose()
  $font.Dispose()
  $sf.Dispose()
  
  $path = Join-Path $dir "icon$s.png"
  $bmp.Save($path, [System.Drawing.Imaging.ImageFormat]::Png)
  $bmp.Dispose()
  Write-Host "Created icon$s.png"
}
Write-Host "Done"
