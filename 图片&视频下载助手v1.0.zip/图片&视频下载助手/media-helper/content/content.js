(function () {
  'use strict';

  const CATEGORIES = ['main', 'sku', 'selling', 'detail', 'traffic', 'review', 'video', 'reviewVideo'];
  const collected = Object.fromEntries(CATEGORIES.map(category => [category, []]));
  const seen = new Map();

  const AREA_PATTERNS = {
    review: [
      'rate', 'review', 'comment', 'feedback', 'evaluate', '评价', '评论', '买家秀', '晒单',
      'j_rate', 'j_reviews', 'j_comment'
    ],
    detail: [
      'desc', 'detail', 'description', 'content', '详情', '描述',
      'j_divitemdesc', 'j_detail', 'j_itemdesc', 'module-detail'
    ],
    traffic: [
      'ztc', 'p4p', 'tuiguang', 'adpic', 'ad-pic', 'ad_pic',
      'creative', 'campaign', '直通车', '推广图', '推广素材', '投放图',
      '广告图', '创意图', '首焦图', '钻展'
    ],
    selling: [
      'sellpoint', 'selling', 'feature', 'marketing', 'benefit', '卖点', '亮点', '看点',
      'shopdetail'
    ],
    sku: [
      'sku', 'sku-wrap', 'skuwrap', 'skuWrapper', 'sku-item', 'skuItem',
      'saleprop', 'sale-prop', 'tsaleprop', 'J_TSaleProp', 'tb-prop',
      'sku-prop', 'skuProp', 'propimg', 'prop-img', 'prop_img', 'color-list',
      'colorpic', 'color-pic', 'color_pic', 'sku-pic', 'sku_pic', 'skupic',
      'sku-map', 'skumap', 'sale-props', 'saleprops', '颜色', '规格', '款式', '尺码'
    ],
    main: [
      'gallery', 'mainpic', 'main-pic', 'tb-pic', 'booth', 'carousel', 'slider', 'swiper',
    'j_imgbooth', 'magnifier', '主图'
    ]
  };

  const SECTION_TEXT_PATTERNS = {
    review: ['用户评价', '商品评价', '评价 ·', '评价·', '买家秀', '晒单', '追评', '评论区', '评价视频'],
    detail: ['图文详情', '商品详情', '详情描述', '宝贝详情', '产品详情', '参数信息'],
    sku: ['颜色分类', '规格分类', '款式选择', '尺码选择'],
    traffic: ['直通车图', '推广素材', '广告创意', '投放图'],
    main: ['视频图集参数', '视频 图集 参数']
  };

  const CATEGORY_ALIASES = {
    selling: 'main'
  };

  const DECORATION_PATTERNS = [
    'icon', 'logo', 'sprite', 'avatar', 'badge', 'star', 'rank', 'qrcode', 'qr',
    'loading', 'blank', 'placeholder', 'transparent', 'default', 'btn', 'button', 'arrow',
    'close', 'search', 'cart', 'wangwang', 'ww-light', 'check', 'checked', 'tick',
    'selected', 'disabled', 'soldout', 'mask', 'label', 'rocket', 'ship', 'shipping',
    'service', 'guarantee', 'promise', 'coupon', 'discount', 'download', 'tao-icon',
    'tb-icon', 'tm-icon', 'shop-logo', 'store-logo', 'seller-logo', 'shop-header',
    'wangpu', 'seller-badge', 'seven', '7day', '7-day', '7天', '七天', '包邮', '退货',
    '售后', '保障', '服务', '配送', '发货', '店标', '店招', '客服', '掌柜', '旺旺', '收藏'
  ];

  const NON_TRAFFIC_VEHICLE_PATTERNS = [
    'vehicle', 'carmodel', 'car-model', 'car_model', 'carpic', 'car-pic', 'car_pic',
    '车型', '车品', '车辆', '汽车', '车款', '适用车型'
  ];

  const CATEGORY_PRIORITY = {
    reviewVideo: 10,
    review: 9,
    sku: 8,
    video: 8,
    main: 7,
    selling: 7,
    detail: 6,
    traffic: 6
  };

  const ROOT_SELECTORS = {
    review: [
      '#reviews',
      '#J_Rate',
      '#J_Reviews',
      '#J_Comment',
      '[class*="rate-list"]',
      '[id*="rate-list"]',
      '[class*="rate-item"]',
      '[id*="rate-item"]',
      '[class*="review"]',
      '[id*="review"]',
      '[class*="comment"]',
      '[id*="comment"]',
      '[class*="evaluate"]',
      '[id*="evaluate"]'
    ],
    detail: [
      '#J_DivItemDesc',
      '#description',
      '#J_ItemDesc',
      '#J_Detail',
      '.J_Detail',
      '.detail-content',
      '.desc-content',
      '.tb-detail',
      '[class*="detail-content"]',
      '[id*="detail-content"]',
      '[class*="desc-content"]',
      '[id*="desc-content"]',
      '[class*="item-desc"]',
      '[id*="item-desc"]',
      '[class*="itemdesc"]',
      '[id*="itemdesc"]',
      '[class*="module-detail"]',
      '[id*="module-detail"]'
    ],
    traffic: [
      '[class*="ztc"]',
      '[id*="ztc"]',
      '[class*="p4p"]',
      '[id*="p4p"]',
      '[class*="tuiguang"]',
      '[id*="tuiguang"]',
      '[class*="adpic"]',
      '[id*="adpic"]',
      '[class*="ad-pic"]',
      '[id*="ad-pic"]',
      '[class*="creative"]',
      '[id*="creative"]'
    ],
    sku: [
      '#J_TSaleProp',
      '.J_TSaleProp',
      '#J_SKU',
      '.J_SKU',
      '#J_Prop',
      '.J_Prop',
      '[class*="sku-wrap"]',
      '[id*="sku-wrap"]',
      '[class*="skuWrapper"]',
      '[id*="skuWrapper"]',
      '[class*="sku-prop"]',
      '[id*="sku-prop"]',
      '[class*="skuProp"]',
      '[id*="skuProp"]',
      '[class*="sale-prop"]',
      '[id*="sale-prop"]',
      '[class*="saleprop"]',
      '[id*="saleprop"]',
      '[class*="prop-img"]',
      '[id*="prop-img"]',
      '[class*="propImg"]',
      '[id*="propImg"]',
      '[class*="color-list"]',
      '[id*="color-list"]',
      '[class*="tb-prop"]',
      '[id*="tb-prop"]'
    ],
    main: [
      '#J_ImgBooth',
      '.J_ImgBooth',
      '[id*="ImgBooth"]',
      '#J_UlThumb',
      '.tb-thumb',
      '.tmall-pic',
      '.gallery',
      '.mainpic',
      '.main-pic',
      '[class*="main-gallery"]',
      '[id*="main-gallery"]',
      '[class*="pic-gallery"]',
      '[id*="pic-gallery"]',
      '[class*="item-gallery"]',
      '[id*="item-gallery"]',
      '[class*="product-gallery"]',
      '[id*="product-gallery"]',
      '[class*="thumb"]',
      '[id*="thumb"]'
    ]
  };

  const IMAGE_ATTRS = [
    'data-ks-lazyload',
    'data-src',
    'data-srcset',
    'data-lazyload',
    'data-original',
    'data-original-src',
    'data-img',
    'data-img-url',
    'data-image',
    'data-image-url',
    'data-background',
    'data-bg',
    'data-thumb',
    'data-thumbnail',
    'data-url',
    'srcset',
    'src'
  ];

  const VIDEO_ATTRS = [
    'src',
    'data-src',
    'data-video',
    'data-video-src',
    'data-video-url',
    'data-videourl',
    'data-url',
    'data-mp4',
    'data-play-url',
    'data-playurl'
  ];

  const POSTER_ATTRS = [
    'poster',
    'data-poster',
    'data-cover',
    'data-cover-url',
    'data-pic',
    'data-image',
    'data-img',
    'data-thumb',
    'data-thumbnail',
    'data-preview',
    'data-preview-url'
  ];

  const IMAGE_ELEMENT_SELECTOR = [
    'img[src]',
    'img[srcset]',
    'img[data-src]',
    'img[data-srcset]',
    'img[data-ks-lazyload]',
    'img[data-lazyload]',
    'img[data-original]',
    'img[data-original-src]',
    'img[data-img]',
    'img[data-img-url]',
    'img[data-image]',
    'img[data-image-url]',
    'img[data-url]',
    '[style*="url("]',
    '[data-background]',
    '[data-bg]',
    '[data-src]',
    '[data-lazyload]',
    '[data-original]',
    '[data-original-src]',
    '[data-img]',
    '[data-img-url]',
    '[data-image]',
    '[data-image-url]',
    '[data-thumb]',
    '[data-thumbnail]',
    '[data-url]'
  ].join(',');

  function normalizeUrl(url) {
    if (!url || url.startsWith('data:')) return null;
    url = url.replace(/\\\//g, '/').trim();
    if (url.startsWith('//')) url = 'https:' + url;
    try {
      const parsed = new URL(url, window.location.href);
      parsed.hash = '';
      return parsed.href;
    } catch (e) {
      return null;
    }
  }

  function stripSizeSuffix(url) {
    if (!url) return url;
    let stripped = url;
    if (url.includes('img.alicdn.com') || url.includes('gw.alicdn.com') || url.includes('taobaocdn.com')) {
      stripped = url
        .replace(/(\.(?:jpg|jpeg|png|webp|gif|bmp))_[^?#]+(?=$|[?#])/i, '$1')
        .replace(/_\d+x\d+.*?(?=\.(jpg|jpeg|png|webp|gif|bmp)(\?|$))/i, '')
        .replace(/_\d+x\d+.*?$/, '')
        .replace(/_sum(?=\.\w+(\?|$))/i, '');
    }
    try {
      const parsed = new URL(stripped);
      parsed.search = '';
      parsed.hash = '';
      return parsed.href;
    } catch (e) {
      return stripped.split('?')[0].split('#')[0];
    }
  }

  function isImageUrl(url) {
    if (!url) return false;
    const clean = url.split('?')[0].split('#')[0].toLowerCase();
    return /\.(jpg|jpeg|png|webp|gif|bmp)$/i.test(clean) ||
      /\.(jpg|jpeg|png|webp|gif|bmp)_/i.test(clean);
  }

  function isVideoUrl(url) {
    if (!url) return false;
    const lower = url.toLowerCase();
    const clean = lower.split('?')[0].split('#')[0];
    if (/\.(mp4|webm|mov|avi|flv|m3u8|ts)$/i.test(clean)) return true;
    if (lower.includes('.m3u8') || lower.includes('.mp4')) return true;
    try {
      const parsed = new URL(url, window.location.href);
      const host = parsed.hostname.toLowerCase();
      const path = parsed.pathname.toLowerCase();
      return host.endsWith('video.taobao.com') && path.includes('/play/');
    } catch (e) {
      return false;
    }
  }

  function isRelevantDomain(url) {
    try {
      const host = new URL(url).hostname.toLowerCase();
      return host === 'alicdn.com' ||
        host.endsWith('.alicdn.com') ||
        host === 'taobaocdn.com' ||
        host.endsWith('.taobaocdn.com') ||
        host === 'tbcdn.cn' ||
        host.endsWith('.tbcdn.cn') ||
        host === 'aliexpress-media.com' ||
        host.endsWith('.aliexpress-media.com') ||
        host === 'aliyuncs.com' ||
        host.endsWith('.aliyuncs.com') ||
        host === 'taobao.com' ||
        host.endsWith('.taobao.com') ||
        host === 'tmall.com' ||
        host.endsWith('.tmall.com');
    } catch (e) {
      return false;
    }
  }

  function getAttrUrl(el, attrs, includeVideo = false) {
    for (const attr of attrs) {
      const val = el.getAttribute(attr);
      if (!val) continue;
      const url = findFirstMediaUrl(val, includeVideo);
      if (!url) continue;
      if (isImageUrl(url) || (includeVideo && isVideoUrl(url))) return url;
    }
    return null;
  }

  function getAttrUrls(el, attrs, includeVideo = false) {
    const urls = [];
    for (const attr of attrs) {
      const val = el.getAttribute(attr);
      if (!val) continue;
      urls.push(...findMediaUrls(val, includeVideo));
    }
    return uniqueUrls(urls);
  }

  function findFirstMediaUrl(value, includeVideo = false) {
    return findMediaUrls(value, includeVideo)[0] || null;
  }

  function findMediaUrls(value, includeVideo = false) {
    if (!value) return [];
    const normalized = String(value)
      .replace(/\\\//g, '/')
      .replace(/&amp;/g, '&')
      .trim();
    const urls = [];
    const directUrl = looksLikeStandaloneMediaValue(normalized) ? normalizeUrl(normalized) : null;
    if (directUrl && (isImageUrl(directUrl) || (includeVideo && isVideoUrl(directUrl)))) {
      urls.push(directUrl);
    }

    const mediaPattern = includeVideo
      ? /(https?:)?\/\/[^"'\s<>,)]+?\.(?:jpg|jpeg|png|webp|gif|bmp|mp4|webm|mov|avi|flv|m3u8|ts)(?:_[^"'\s<>,)]*)?(?:\?[^"'\s<>,)]*)?/gi
      : /(https?:)?\/\/[^"'\s<>,)]+?\.(?:jpg|jpeg|png|webp|gif|bmp)(?:_[^"'\s<>,)]*)?(?:\?[^"'\s<>,)]*)?/gi;
    for (const match of normalized.matchAll(mediaPattern)) {
      const url = normalizeUrl(match[0]);
      if (url && (isImageUrl(url) || (includeVideo && isVideoUrl(url)))) urls.push(url);
    }
    return uniqueUrls(urls);
  }

  function looksLikeStandaloneMediaValue(value) {
    const text = String(value || '').trim();
    if (!text || /[\s"'{}[\]]/.test(text)) return false;
    return /^(https?:)?\/\//i.test(text) ||
      /^[./]?[^\s"'{}[\]]+\.(?:jpg|jpeg|png|webp|gif|bmp|mp4|webm|mov|avi|flv|m3u8|ts)(?:_|[?#]|$)/i.test(text);
  }

  function uniqueUrls(urls) {
    return Array.from(new Set(urls.filter(Boolean)));
  }

  function getElementText(el, depth = 8) {
    const parts = [];
    let node = el;
    for (let i = 0; i < depth && node; i++) {
      parts.push(
        node.id || '',
        typeof node.className === 'string' ? node.className : '',
        node.getAttribute && node.getAttribute('data-spm') || '',
        node.getAttribute && node.getAttribute('aria-label') || '',
        node.getAttribute && node.getAttribute('role') || '',
        node.getAttribute && node.getAttribute('alt') || '',
        node.getAttribute && node.getAttribute('title') || '',
        node.getAttribute && node.getAttribute('data-title') || '',
        node.getAttribute && node.getAttribute('data-label') || '',
        node.getAttribute && node.getAttribute('data-value') || '',
        node.getAttribute && node.getAttribute('data-property') || '',
        node.getAttribute && node.getAttribute('data-sku-id') || '',
        node.getAttribute && node.getAttribute('data-prop') || '',
        node.getAttribute && node.getAttribute('data-prop-name') || '',
        node.getAttribute && node.getAttribute('data-name') || '',
        node.getAttribute && node.getAttribute('data-category') || '',
        node.getAttribute && node.getAttribute('data-type') || ''
      );
      node = node.parentElement;
    }
    return parts.join(' ').toLowerCase();
  }

  function getNearbyContentText(el, depth = 5) {
    const parts = [];
    let node = el;
    for (let i = 0; i < depth && node; i++) {
      if (/^(body|html)$/i.test(node.tagName || '')) break;
      const text = (node.textContent || '').replace(/\s+/g, ' ').trim();
      if (text && text.length <= 800 && !hasMixedSectionText(text)) parts.push(text);
      node = node.parentElement;
    }
    return parts.join(' ').toLowerCase();
  }

  function hasMixedSectionText(text) {
    const lower = String(text || '').toLowerCase();
    let matched = 0;
    Object.values(SECTION_TEXT_PATTERNS).forEach(patterns => {
      if (matchesAny(lower, patterns)) matched++;
    });
    return matched > 1;
  }

  function matchesAny(text, patterns) {
    return patterns.some(pattern => text.includes(pattern.toLowerCase()));
  }

  function closestAny(el, selectors) {
    if (!el || !el.closest) return null;
    for (const selector of selectors) {
      try {
        const match = el.closest(selector);
        if (match) return match;
      } catch (e) {}
    }
    return null;
  }

  function queryAllSafe(selector, root = document) {
    try {
      return Array.from(root.querySelectorAll(selector));
    } catch (e) {
      return [];
    }
  }

  function isInsideCategory(el, category) {
    const selectors = ROOT_SELECTORS[category];
    return !!(selectors && closestAny(el, selectors));
  }

  function getStructuralCategory(el) {
    if (isInsideCategory(el, 'review')) return 'review';
    const nearbyText = getNearbyContentText(el);
    if (matchesAny(nearbyText, SECTION_TEXT_PATTERNS.review)) return 'review';
    if (isInsideCategory(el, 'detail')) return 'detail';
    if (matchesAny(nearbyText, SECTION_TEXT_PATTERNS.detail)) return 'detail';
    if (isInsideCategory(el, 'main')) return 'main';
    if (isInsideCategory(el, 'sku')) return 'sku';
    if (matchesAny(nearbyText, SECTION_TEXT_PATTERNS.sku)) return 'sku';
    if (isInsideCategory(el, 'traffic') && !matchesAny(getElementText(el, 4), NON_TRAFFIC_VEHICLE_PATTERNS)) return 'traffic';
    return null;
  }

  function isSkuElement(el) {
    const structural = getStructuralCategory(el);
    if (structural === 'review' || structural === 'detail' || structural === 'main') return false;
    return structural === 'sku' || matchesAny(getElementText(el, 3), AREA_PATTERNS.sku);
  }

  function isReviewElement(el) {
    return getStructuralCategory(el) === 'review' ||
      matchesAny(getNearbyContentText(el), SECTION_TEXT_PATTERNS.review) ||
      matchesAny(getElementText(el, 3), ['review', 'comment', 'rate-item', 'evaluate']);
  }

  function isTrafficElement(el) {
    if (getStructuralCategory(el) === 'review') return false;
    const text = getElementText(el, 4);
    if (matchesAny(text, NON_TRAFFIC_VEHICLE_PATTERNS)) return false;
    return getStructuralCategory(el) === 'traffic' || matchesAny(text, AREA_PATTERNS.traffic);
  }

  function getImageSize(el) {
    const width = Number(el.naturalWidth || el.width || el.getAttribute('width') || el.getAttribute('data-width') || 0);
    const height = Number(el.naturalHeight || el.height || el.getAttribute('height') || el.getAttribute('data-height') || 0);
    return { width, height };
  }

  function inferUrlSize(url) {
    const text = String(url || '');
    const match = text.match(/(?:_|\/)(\d{2,5})x(\d{2,5})(?:[_.\/]|$)/i);
    if (!match) return { width: 0, height: 0 };
    return { width: Number(match[1]), height: Number(match[2]) };
  }

  function hasUsefulSize(el, url, category) {
    const { width, height } = getImageSize(el);
    const size = (width && height) ? { width, height } : inferUrlSize(url);
    const minSide = category === 'sku' ? 40 : 80;
    if (!size.width || !size.height) return true;
    return size.width >= minSide && size.height >= minSide;
  }

  function isDecorationImage(el, url) {
    const text = `${getElementText(el, 3)} ${url}`.toLowerCase();
    if (isSkuElement(el) && isImageUrl(url)) {
      if (matchesAny(text, DECORATION_PATTERNS)) return true;
    } else if (matchesAny(text, DECORATION_PATTERNS)) {
      return true;
    }

    if (isServiceIconLike(el, url)) return true;
    if (!hasUsefulSize(el, url, isSkuElement(el) ? 'sku' : 'main')) return true;

    try {
      const path = new URL(url).pathname.toLowerCase();
      if (path.endsWith('.ico') || path.includes('/favicon')) return true;
      if (path.includes('/tb1') && path.includes('logo')) return true;
      if (/\/(?:icon|logo|sprite|avatar|qrcode|qr)\//i.test(path)) return true;
    } catch (e) {}

    return false;
  }

  function isServiceIconLike(el, url) {
    const text = `${getElementText(el, 2)} ${url}`.toLowerCase();
    if (/(rocket|ship|shipping|service|guarantee|promise|coupon|discount|7day|7-day|seven|tao-icon|tb-icon|tm-icon|shop-logo|store-logo|seller-logo|shop-header|wangpu|seller-badge)/i.test(text)) {
      return true;
    }
    if (/(火箭|运费|包邮|发货|配送|七天|7天|退货|售后|保障|服务|承诺|优惠|券|淘宝|淘|店标|店招|客服|掌柜|旺旺|收藏)/.test(text)) {
      return true;
    }

    const { width, height } = getImageSize(el);
    const area = width && height ? width * height : 0;
    if (area && area < 50000 && /tfs|alicdn/.test(text) && !isSkuElement(el)) return true;

    return false;
  }

  function classifyElement(el, fallback = null) {
    fallback = CATEGORY_ALIASES[fallback] || fallback;
    const structural = getStructuralCategory(el);
    if (structural === 'review' || structural === 'detail') return structural;

    const text = getElementText(el, 3);
    const nearbyText = getNearbyContentText(el);
    if (matchesAny(nearbyText, SECTION_TEXT_PATTERNS.review)) return 'review';
    if (matchesAny(nearbyText, SECTION_TEXT_PATTERNS.detail)) return 'detail';
    if (matchesAny(nearbyText, SECTION_TEXT_PATTERNS.sku)) return 'sku';
    if (matchesAny(text, AREA_PATTERNS.sku)) return 'sku';
    if (structural) return structural;
    if (matchesAny(text, AREA_PATTERNS.review)) return 'review';
    if (matchesAny(text, AREA_PATTERNS.detail)) return 'detail';
    if (matchesAny(text, AREA_PATTERNS.main) || matchesAny(text, AREA_PATTERNS.selling)) return 'main';
    if (matchesAny(text, AREA_PATTERNS.traffic) && !matchesAny(text, NON_TRAFFIC_VEHICLE_PATTERNS)) return 'traffic';
    return fallback;
  }

  function addMedia(category, url, extra = {}) {
    if (!url || !isRelevantDomain(url)) return;
    category = CATEGORY_ALIASES[category] || category;
    if (!CATEGORIES.includes(category)) return;
    if ((category === 'video' || category === 'reviewVideo') && !extra.poster) {
      extra = { ...extra, poster: getDefaultPoster(category) };
    }
    const key = stripSizeSuffix(url);
    const existingCategory = seen.get(key);
    if (existingCategory) {
      const existingPriority = CATEGORY_PRIORITY[existingCategory] || 0;
      const nextPriority = CATEGORY_PRIORITY[category] || 0;
      if (nextPriority > existingPriority) {
        moveMediaItem(existingCategory, category, key, extra);
        seen.set(key, category);
      } else {
        mergeMediaItem(existingCategory, key, extra);
      }
      return;
    }
    seen.set(key, category);

    collected[category].push({
      url,
      highResUrl: stripSizeSuffix(url),
      filename: guessFilename(url, category),
      ...extra
    });
  }

  function getDefaultPoster(category) {
    const preferred = category === 'reviewVideo' ? collected.review : collected.main;
    const fallback = category === 'reviewVideo' ? collected.main : collected.review;
    return findPosterInItems(preferred) || findPosterInItems(fallback) || '';
  }

  function findPosterInItems(items = []) {
    const item = items.find(entry => isImageUrl(entry.highResUrl || entry.url));
    return item ? (item.highResUrl || item.url) : '';
  }

  function mergeMediaItem(category, key, extra = {}) {
    const item = findMediaItem(category, key);
    if (!item) return;
    if (extra.poster && !item.poster) item.poster = extra.poster;
  }

  function moveMediaItem(fromCategory, toCategory, key, extra = {}) {
    const source = collected[fromCategory];
    if (!source) return;
    const index = source.findIndex(item => getSeenKey(item.url) === key);
    if (index === -1) return;
    const [item] = source.splice(index, 1);
    collected[toCategory].push({
      ...item,
      ...extra,
      filename: guessFilename(item.url, toCategory)
    });
  }

  function findMediaItem(category, key) {
    const source = collected[category];
    return source && source.find(item => getSeenKey(item.url) === key);
  }

  function getSeenKey(url) {
    return stripSizeSuffix(url);
  }

  function collectImageElement(img, fallback = null) {
    getImageUrlsFromElement(img).forEach(url => {
      if (!url || !isImageUrl(url) || !isRelevantDomain(url)) return;
      if (isDecorationImage(img, url)) return;

      const category = classifyElement(img, fallback);
      if (!category) return;
      if (!hasUsefulSize(img, url, category)) return;
      addMedia(category, url);
    });
  }

  function getImageUrlsFromElement(el) {
    const urls = getAttrUrls(el, IMAGE_ATTRS);
    const style = el.getAttribute && el.getAttribute('style');
    if (style) urls.push(...findMediaUrls(style));
    return uniqueUrls(urls).filter(isImageUrl);
  }

  function collectImagesInRoots(selectors, fallback, options = {}) {
    const roots = new Set();
    selectors.forEach(selector => {
      queryAllSafe(selector).forEach(root => roots.add(root));
    });

    roots.forEach(root => {
      const targets = new Set();
      if (root.matches && root.matches(IMAGE_ELEMENT_SELECTOR)) targets.add(root);
      queryAllSafe(IMAGE_ELEMENT_SELECTOR, root).forEach(target => targets.add(target));

      targets.forEach(target => {
        if (options.skipSku && isSkuElement(target)) return;
        if (options.skipReview && isReviewElement(target)) return;
        if (options.skipDetail && isInsideCategory(target, 'detail')) return;
        if (options.skipTraffic && isTrafficElement(target) && !isInsideCategory(target, 'detail')) return;
        collectImageElement(target, fallback);
      });
    });
  }

  function collectDomImages() {
    collectImagesInRoots(ROOT_SELECTORS.main, 'main', { skipSku: true, skipReview: true, skipDetail: true, skipTraffic: true });
    collectViewportMainImages();
    collectImagesInRoots(ROOT_SELECTORS.sku, 'sku');
    collectImagesInRoots(ROOT_SELECTORS.review, 'review', { skipSku: true });
    collectImagesInRoots(ROOT_SELECTORS.traffic, 'traffic', { skipSku: true, skipReview: true });
    collectImagesInRoots(ROOT_SELECTORS.detail, 'detail', { skipSku: true, skipReview: true, skipTraffic: true });

    document.querySelectorAll(IMAGE_ELEMENT_SELECTOR).forEach(img => {
      collectImageElement(img);
    });
  }

  function collectViewportMainImages() {
    queryAllSafe(IMAGE_ELEMENT_SELECTOR).forEach(target => {
      if (!looksLikeViewportMainMedia(target)) return;
      getImageUrlsFromElement(target).forEach(url => {
        if (!url || !isImageUrl(url) || !isRelevantDomain(url)) return;
        if (!looksLikeViewportMainMedia(target) && isDecorationImage(target, url)) return;
        if (isLikelyDecorativeUrl(url)) return;
        addMedia('main', url);
      });
    });
  }

  function looksLikeViewportMainMedia(el) {
    if (getStructuralCategory(el) && getStructuralCategory(el) !== 'main') return false;
    if (matchesAny(getElementText(el, 2), AREA_PATTERNS.sku)) return false;
    if (isSkuElement(el) || isReviewElement(el) || isInsideCategory(el, 'detail') || isTrafficElement(el)) return false;
    if (!el.getBoundingClientRect) return false;

    const rect = el.getBoundingClientRect();
    if (!rect || rect.width <= 0 || rect.height <= 0) return false;
    const viewportWidth = Math.max(
      window.innerWidth || 0,
      document.documentElement && document.documentElement.clientWidth || 0,
      1000
    );
    const top = rect.top + (window.scrollY || window.pageYOffset || 0);
    const maxTop = Math.max(900, (window.innerHeight || 800) * 1.2);
    if (top > maxTop) return false;
    if (rect.left > viewportWidth * 0.68) return false;

    const largeMainVisual = rect.width >= 180 && rect.height >= 180;
    const leftThumbRail = rect.left < 220 && rect.width >= 44 && rect.height >= 44;
    return largeMainVisual || leftThumbRail;
  }

  function collectScriptMedia() {
    const candidates = [];
    const scripts = document.querySelectorAll('script');

    for (const script of scripts) {
      const text = (script.textContent || '').replace(/\\\//g, '/');
      if (!/alicdn\.com|taobaocdn\.com|tbcdn\.cn|aliyuncs\.com|video\.taobao\.com/i.test(text)) continue;

      const lower = text.toLowerCase();
      const looksLikeProductMediaData = lower.includes('auctionimages') ||
        lower.includes('mainpic') ||
        lower.includes('sku') ||
        lower.includes('apiitemdesc') ||
        lower.includes('itempic') ||
        lower.includes('imageurl') ||
        lower.includes('videourl') ||
        lower.includes('videoid') ||
        lower.includes('playurl') ||
        lower.includes('review') ||
        lower.includes('rate') ||
        lower.includes('comment') ||
        lower.includes('traffic') ||
        lower.includes('ztc') ||
        lower.includes('p4p') ||
        lower.includes('tuiguang') ||
        lower.includes('promotion') ||
        lower.includes('detail');

      if (!looksLikeProductMediaData) continue;

      const matches = text.match(/(https?:)?\/\/[^"'\s<>]+?\.(?:jpg|jpeg|png|webp|gif)(?:_[^"'\s<>]*)?/gi) || [];
      for (const match of matches) {
        const url = normalizeUrl(match);
        const category = classifyScriptUrl(text, match);
        if (url && category && isImageUrl(url) && !isLikelyDecorativeUrl(url)) {
          candidates.push({ category, url });
        }
      }

      const videoMatches = text.match(/(https?:)?\/\/[^"'\s<>]+?(?:\.(?:mp4|webm|mov|avi|flv|m3u8|ts)|video\.taobao\.com\/play\/)[^"'\s<>]*/gi) || [];
      for (const match of videoMatches) {
        const url = normalizeUrl(match);
        if (url && isVideoUrl(url)) {
          candidates.push({ category: classifyScriptVideoUrl(text, match), url, extra: { poster: findScriptPosterNear(text, match) } });
        }
      }
    }

    candidates.slice(0, 120).forEach(item => addMedia(item.category, item.url, item.extra || {}));
  }

  function classifyScriptUrl(scriptText, rawUrl) {
    const lower = scriptText.toLowerCase();
    const url = String(rawUrl || '').toLowerCase();
    const index = lower.indexOf(url.replace(/^https?:/, ''));
    const before = index >= 0 ? lower.slice(Math.max(0, index - 420), index) : lower;
    const after = index >= 0 ? lower.slice(index + url.length, index + url.length + 120) : '';
    const localStart = index >= 0 ? Math.max(
      lower.lastIndexOf('{', index),
      lower.lastIndexOf(',', index),
      lower.lastIndexOf(';', index),
      lower.lastIndexOf('\n', index),
      index - 120
    ) : 0;
    const localEnd = index >= 0 ? firstPositive([
      lower.indexOf(',', index + url.length),
      lower.indexOf(';', index + url.length),
      lower.indexOf('\n', index + url.length)
    ], index + url.length + 30) : lower.length;
    const localBefore = index >= 0 ? lower.slice(Math.max(0, localStart), index) : before;
    const localAfter = index >= 0 ? lower.slice(index + url.length, Math.min(lower.length, localEnd)) : after;
    const localContext = `${localBefore} ${localAfter}`;

    if (isLikelyDecorativeScriptContext(rawUrl, localContext)) return null;
    if (matchesAny(localContext, NON_TRAFFIC_VEHICLE_PATTERNS) && !matchesAny(localContext, AREA_PATTERNS.traffic)) {
      return null;
    }

    const markers = {
      review: ['review', 'rate', 'comment', 'feedback', 'evaluate', '评价', '评论', '买家秀', '晒单'],
      traffic: ['traffic', 'ztc', 'p4p', 'tuiguang', 'promotion', 'adpic', 'ad-pic', 'ad_pic', 'creative', 'campaign', '直通车', '推广图', '推广素材', '投放图', '广告图', '创意图', '首焦图', '钻展'],
      detail: ['apiitemdesc', 'itemdesc', 'description', 'detail', 'desc', '详情', '描述'],
      sku: ['sku', 'skuimage', 'sku-image', 'skuimg', 'sku-img', 'skupic', 'sku-pic', 'sku_pic', 'saleprop', 'sale-prop', 'saleprops', 'tsaleprop', 'propimg', 'prop-img', 'prop_img', 'colorpic', 'color-pic', 'color_pic', '颜色', '规格', '款式', '尺码'],
      main: ['auctionimages', 'mainpic', 'itempic', 'sellpoint', 'selling', 'feature', 'marketing', 'benefit', 'itemvideo', 'mainvideo', 'productvideo', '商品视频', '卖点', '亮点', '看点']
    };
    for (const category of ['sku', 'review', 'traffic', 'detail', 'main']) {
      if (markers[category].some(word => localContext.includes(word.toLowerCase()))) return category;
    }

    const ranked = Object.entries(markers).map(([category, words]) => ({
      category,
      index: Math.max(...words.map(word => before.lastIndexOf(word)))
    })).sort((a, b) => b.index - a.index);

    if (ranked[0] && ranked[0].index >= 0) return ranked[0].category;
    if (markers.review.some(word => after.includes(word))) return 'review';
    if (markers.traffic.some(word => after.includes(word))) return 'traffic';
    if (markers.detail.some(word => after.includes(word))) return 'detail';
    if (markers.sku.some(word => after.includes(word))) return 'sku';
    if (markers.main.some(word => after.includes(word))) return 'main';
    return null;
  }

  function classifyScriptVideoUrl(scriptText, rawUrl) {
    const lower = scriptText.toLowerCase();
    const url = String(rawUrl || '').toLowerCase();
    const index = lower.indexOf(url.replace(/^https?:/, ''));
    const before = index >= 0 ? lower.slice(Math.max(0, index - 520), index) : lower;
    const after = index >= 0 ? lower.slice(index + url.length, index + url.length + 80) : '';
    const localStart = index >= 0 ? Math.max(
      lower.lastIndexOf('{', index),
      lower.lastIndexOf('[', index),
      lower.lastIndexOf(',', index),
      lower.lastIndexOf('\n', index),
      index - 160
    ) : 0;
    const localBefore = index >= 0 ? lower.slice(Math.max(0, localStart), index) : before;
    const localContext = `${localBefore} ${after}`;
    const reviewMarkers = ['review', 'reviewfeeds', '/review/', 'rate', 'comment', 'feedback', 'evaluate', '评价', '评论', '买家秀', '晒单'];
    const productMarkers = ['videourl', 'video-url', 'videoid', 'video-id', 'playurl', 'play-url', 'itemvideo', 'mainvideo', 'productvideo', 'product-video', 'main-video', '商品视频'];
    const lastReview = Math.max(...reviewMarkers.map(word => before.lastIndexOf(word)));
    const lastProduct = Math.max(...productMarkers.map(word => before.lastIndexOf(word)));

    if (/\/(?:review|rate|comment)(?:\/|[-_])/i.test(url)) return 'reviewVideo';
    if (reviewMarkers.some(word => localContext.includes(word.toLowerCase()))) return 'reviewVideo';
    if (productMarkers.some(word => localContext.includes(word.toLowerCase()))) return 'video';
    if (lastReview > lastProduct) return 'reviewVideo';
    if (productMarkers.some(word => after.includes(word))) return 'video';
    if (reviewMarkers.some(word => after.includes(word))) return 'reviewVideo';
    return 'video';
  }

  function firstPositive(values, fallback) {
    const candidates = values.filter(value => value >= 0);
    return candidates.length ? Math.min(...candidates) : fallback;
  }

  function findScriptPosterNear(scriptText, rawUrl) {
    const lower = scriptText.toLowerCase();
    const url = String(rawUrl || '').toLowerCase();
    const index = lower.indexOf(url.replace(/^https?:/, ''));
    if (index < 0) return '';
    const start = Math.max(0, index - 500);
    const context = scriptText.slice(start, Math.min(scriptText.length, index + url.length + 500));
    const localUrlIndex = index - start;
    const imagePattern = /(https?:)?\/\/[^"'\s<>,)]+?\.(?:jpg|jpeg|png|webp|gif|bmp)(?:_[^"'\s<>,)]*)?(?:\?[^"'\s<>,)]*)?/gi;
    const candidates = [];

    for (const match of context.matchAll(imagePattern)) {
      const imageUrl = normalizeUrl(match[0]);
      if (!imageUrl || !isImageUrl(imageUrl) || !isRelevantDomain(imageUrl) || isLikelyDecorativeUrl(imageUrl)) continue;
      const imageIndex = match.index || 0;
      const between = context.slice(Math.min(localUrlIndex, imageIndex), Math.max(localUrlIndex, imageIndex)).toLowerCase();
      let score = Math.abs(imageIndex - localUrlIndex);
      if (imageIndex > localUrlIndex && /poster|cover|pic|image|thumb|封面|预览/.test(between)) score -= 400;
      if (/cover|poster|thumb|封面|预览/i.test(between)) score -= 120;
      candidates.push({ url: imageUrl, score });
    }

    candidates.sort((a, b) => a.score - b.score);
    return candidates[0] ? candidates[0].url : '';
  }

  function isLikelyDecorativeUrl(url) {
    const lower = url.toLowerCase();
    return DECORATION_PATTERNS.some(pattern => lower.includes(pattern)) ||
      lower.includes('sprite') ||
      lower.includes('iconfont') ||
      lower.includes('favicon');
  }

  function isLikelyDecorativeScriptContext(rawUrl, context) {
    const text = `${rawUrl || ''} ${context || ''}`.toLowerCase();
    if (DECORATION_PATTERNS.some(pattern => text.includes(pattern.toLowerCase()))) return true;
    return /(shop-logo|store-logo|seller-logo|serviceicon|service-icon|iconfont|sprite|favicon|店标|店招|客服|旺旺|服务|保障|承诺)/i.test(text);
  }

  function collectMetaImage() {
    const metaImage = document.querySelector('meta[property="og:image"]');
    if (!metaImage) return;

    const url = normalizeUrl(metaImage.getAttribute('content'));
    if (url && isImageUrl(url) && isRelevantDomain(url) && !isLikelyDecorativeUrl(url)) {
      addMedia('main', url);
    }
  }

  function collectVideos() {
    document.querySelectorAll('video').forEach(video => {
      const category = getVideoCategory(video);
      const poster = findPosterUrl(video, category);
      const urls = getAttrUrls(video, VIDEO_ATTRS, true).filter(url => isVideoUrl(url) && isRelevantDomain(url));

      video.querySelectorAll('source').forEach(source => {
        urls.push(...getAttrUrls(source, VIDEO_ATTRS, true).filter(url => isVideoUrl(url) && isRelevantDomain(url)));
      });

      const url = uniqueUrls(urls)[0];
      if (url) addMedia(category, url, { poster });
    });

    document.querySelectorAll('[src], [data-src], [data-video], [data-video-url], [data-videourl], [data-url], [data-mp4], [data-play-url], [data-playurl]').forEach(el => {
      if (['VIDEO', 'SOURCE'].includes(el.tagName)) return;
      const category = getVideoCategory(el);
      const poster = findPosterUrl(el, category);
      const url = getAttrUrls(el, VIDEO_ATTRS, true).find(item => isVideoUrl(item) && isRelevantDomain(item));
      if (url) addMedia(category, url, { poster });
    });

    document.querySelectorAll('[class*="rate"], [id*="rate"], [class*="review"], [id*="review"], [class*="comment"], [id*="comment"], [class*="video"], [id*="video"]').forEach(area => {
      const text = `${area.textContent || ''} ${Array.from(area.attributes || []).map(attr => attr.value).join(' ')}`.replace(/\\\//g, '/');
      const matches = text.match(/(https?:)?\/\/[^"'\s<>]+?(?:\.(?:mp4|webm|mov|avi|flv|m3u8|ts)|video\.taobao\.com\/play\/)[^"'\s<>]*/gi) || [];
      const category = getVideoCategory(area);
      const poster = findPosterUrl(area, category);
      matches.forEach(match => {
        const url = normalizeUrl(match);
        if (url && isVideoUrl(url) && isRelevantDomain(url)) {
          addMedia(category, url, { poster });
        }
      });
    });
  }

  function getVideoCategory(el) {
    const category = classifyElement(el);
    if (category === 'review') return 'reviewVideo';
    const text = `${getElementText(el, 4)} ${getNearbyContentText(el)}`;
    return matchesAny(text, SECTION_TEXT_PATTERNS.review) || matchesAny(text, AREA_PATTERNS.review)
      ? 'reviewVideo'
      : 'video';
  }

  function findPosterUrl(el, category = null) {
    const direct = getAttrUrls(el, POSTER_ATTRS).find(url => isImageUrl(url) && isRelevantDomain(url));
    if (direct) return direct;

    const styleUrl = findMediaUrls(el.getAttribute && el.getAttribute('style')).find(url => isImageUrl(url) && isRelevantDomain(url));
    if (styleUrl) return styleUrl;

    const container = closestAny(el, [
      '[class*="video"]',
      '[id*="video"]',
      '[class*="player"]',
      '[id*="player"]',
      '.gallery',
      '.mainpic',
      '.swiper',
      '.carousel'
    ]) || el.parentElement;

    if (!container) return '';

    const candidates = [];
    if (container.matches && container.matches(IMAGE_ELEMENT_SELECTOR)) candidates.push(container);
    queryAllSafe(IMAGE_ELEMENT_SELECTOR, container).forEach(item => candidates.push(item));

    for (const candidate of candidates) {
      const url = getImageUrlsFromElement(candidate).find(item => isImageUrl(item) && isRelevantDomain(item) && !isDecorationImage(candidate, item));
      if (url) return url;
    }

    return getDefaultPoster(category);
  }

  function dedupe(items) {
    const map = new Map();
    for (const item of items) {
      const key = getSeenKey(item.url);
      if (!map.has(key)) {
        map.set(key, item);
      } else if (item.poster && !map.get(key).poster) {
        map.get(key).poster = item.poster;
      }
    }
    return Array.from(map.values());
  }

  function guessFilename(url, category) {
    try {
      const parsed = new URL(url);
      const last = parsed.pathname.split('/').filter(Boolean).pop() || 'media';
      const cleanName = decodeURIComponent(last)
        .replace(/_\d+x\d+.*?(?=\.)/, '')
        .replace(/\.[^.]+$/, '')
        .replace(/[<>:"/\\|?*\s]+/g, '_')
        .slice(0, 44) || 'media';
      const ext = last.includes('.') ? last.split('.').pop().split('_')[0] : (category.includes('Video') || category === 'video' ? 'mp4' : 'jpg');
      const prefixMap = {
        main: '主图',
        sku: '选购图',
        selling: '卖点图',
        detail: '详情图',
        traffic: '直通车图',
        review: '评价图',
        video: '视频',
        reviewVideo: '评价视频'
      };
      return `${prefixMap[category] || '媒体'}_${cleanName}.${ext}`;
    } catch (e) {
      return `${category}_${Date.now()}.jpg`;
    }
  }

  function extractAll() {
    CATEGORIES.forEach(category => {
      collected[category] = [];
    });
    seen.clear();

    collectMetaImage();
    collectDomImages();
    collectScriptMedia();
    collectVideos();

    const result = {};
    CATEGORIES.forEach(category => {
      result[category] = dedupe(collected[category]);
    });
    result.total = CATEGORIES.reduce((sum, category) => sum + result[category].length, 0);
    result.url = window.location.href;
    result.title = document.title;
    result.host = window.location.hostname;
    return result;
  }

  globalThis.__mediaHelperExtractMedia = extractAll;
})();
