const $ = (sel) => document.querySelector(sel);
const $$ = (sel) => document.querySelectorAll(sel);

let allMedia = { main: [], sku: [], selling: [], detail: [], traffic: [], review: [], video: [], reviewVideo: [] };
let selectedItems = new Set();
let isPageSupported = false;
let collapsedGroups = new Set();
let currentPageUrl = '';
let currentMediaMode = 'images';

const GROUPS = [
  { key: 'main', label: '主图/卖点图', hint: '商品首屏、轮播图与卖点素材', mediaType: 'image' },
  { key: 'sku', label: '选购图', hint: '颜色、规格、款式图', mediaType: 'image' },
  { key: 'detail', label: '详情图', hint: '详情页长图与内容图', mediaType: 'image' },
  { key: 'traffic', label: '直通车图', hint: '投放图、推广素材、广告创意', mediaType: 'image' },
  { key: 'review', label: '评价图', hint: '评价、买家秀、晒单图片', mediaType: 'image' },
  { key: 'video', label: '商品视频', hint: '商品视频素材', mediaType: 'video' },
  { key: 'reviewVideo', label: '评价视频', hint: '评价区视频素材', mediaType: 'video' }
];

const MODE_TABS = [
  { key: 'images', label: '图片', groupKeys: ['main', 'sku', 'detail', 'traffic', 'review'] },
  {
    key: 'videos',
    label: '视频',
    groupKeys: ['video', 'reviewVideo'],
    note: '如果商品视频还没加载出来，请先在商品页播放或滚动到视频区域，再点底部“刷新”重新提取。'
  },
  { key: 'reviews', label: '评论', groupKeys: ['review', 'reviewVideo'] }
];

document.addEventListener('DOMContentLoaded', () => {
  init();
});

async function init() {
  $('#btnExtract').addEventListener('click', extractMedia);
  $('#btnRefresh').addEventListener('click', refreshExtraction);
  $('#checkAll').addEventListener('change', toggleSelectAll);
  $('#btnDownloadAll').addEventListener('click', downloadAll);
  $('#btnDownloadSelected').addEventListener('click', downloadSelected);
  $('#previewClose').addEventListener('click', closePreview);
  $('#previewDownload').addEventListener('click', downloadPreview);
  $('.preview-backdrop').addEventListener('click', closePreview);

  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') closePreview();
  });

  renderModeTabs();
  bindPageChangeRefresh();
  await checkPage();
}

async function checkPage() {
  try {
    const resp = await sendMessage('CHECK_PAGE');
    if (resp.success && resp.data) {
      const nextUrl = resp.data.url || '';
      const pageChanged = nextUrl !== currentPageUrl || Boolean(resp.data.supported) !== isPageSupported;
      isPageSupported = Boolean(resp.data.supported);
      currentPageUrl = nextUrl;

      if (pageChanged) {
        resetPageState();
      }

      if (isPageSupported) {
        $('#pageInfo').style.display = 'block';
        $('#pageTitle').textContent = resp.data.title || '';
        $('#pageUrl').textContent = resp.data.url || '';
      } else {
        $('#pageInfo').style.display = 'none';
        $('#tipsPanel').style.display = 'flex';
      }
      updateStatus(resp.data);
      setExtractingState(false);
    }
  } catch (err) {
    $('#statusText').textContent = '检测失败';
    showToast('页面检测失败: ' + err.message, 'error');
    setExtractingState(false);
  }
}

function updateStatus(data) {
  $('.status-dot').classList.toggle('active', Boolean(data.supported));

  if (data.supported) {
    if (isHostForDomain(data.host, 'tmall.com')) {
      $('#statusText').textContent = '天猫商品页面';
    } else if (isHostForDomain(data.host, 'taobao.com')) {
      $('#statusText').textContent = '淘宝商品页面';
    }
  } else if (data.isSupportedHost) {
    $('#statusText').textContent = '淘宝/天猫非商品页面';
  } else {
    $('#statusText').textContent = '非淘宝/天猫页面';
  }
}

function resetPageState() {
  allMedia = createEmptyMedia();
  selectedItems.clear();
  collapsedGroups.clear();
  $('#mediaGroups').innerHTML = '';
  $('#emptyState').style.display = 'none';
  $('#actionBar').style.display = 'none';
  $('#loadingState').style.display = 'none';
  renderModeTabs();
  setExtractingState(false);
}

function createEmptyMedia() {
  return { main: [], sku: [], selling: [], detail: [], traffic: [], review: [], video: [], reviewVideo: [] };
}

function setExtractingState(isBusy) {
  const enabled = isPageSupported && !isBusy;
  $('#btnExtract').disabled = !enabled;
  $('#btnRefresh').disabled = !enabled;
}

function bindPageChangeRefresh() {
  if (!chrome.tabs) return;

  chrome.tabs.onActivated.addListener(() => {
    checkPage();
  });

  chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
    if (!tab.active) return;
    if (changeInfo.url || changeInfo.status === 'complete') {
      checkPage();
    }
  });

  chrome.windows.onFocusChanged.addListener((windowId) => {
    if (windowId !== chrome.windows.WINDOW_ID_NONE) {
      checkPage();
    }
  });
}

function isHostForDomain(host, domain) {
  const normalizedHost = String(host || '').toLowerCase();
  return normalizedHost === domain || normalizedHost.endsWith(`.${domain}`);
}

async function extractMedia() {
  setExtractingState(true);
  $('#loadingState').style.display = 'block';
  $('#emptyState').style.display = 'none';
  $('#tipsPanel').style.display = 'none';

  try {
    const resp = await sendMessage('EXTRACT_MEDIA');
    $('#loadingState').style.display = 'none';
    setExtractingState(false);

    if (resp.success && resp.data) {
      allMedia = resp.data;
      renderAll();
      showToast(`提取完成！共 ${allMedia.total} 个文件`, 'success');
    } else {
      showToast(resp.error || '提取失败', 'error');
      $('#emptyState').style.display = 'block';
    }
  } catch (err) {
    $('#loadingState').style.display = 'none';
    setExtractingState(false);
    showToast('提取出错: ' + err.message, 'error');
  }
}

async function refreshExtraction() {
  await checkPage();
  if (isPageSupported) {
    await extractMedia();
  }
}

function getMediaCategory(item) {
  for (const group of GROUPS) {
    if ((allMedia[group.key] || []).includes(item)) return group.key;
  }
  return 'main';
}

function renderAll() {
  if (allMedia.total === 0) {
    $('#emptyState').style.display = 'block';
    $('#actionBar').style.display = 'none';
    $('#mediaGroups').innerHTML = '';
    renderModeTabs();
    return;
  }

  $('#actionBar').style.display = 'flex';
  $('#emptyState').style.display = 'none';
  renderModeTabs();
  updateSelectedInfo();
  renderGroups();
}

function renderGroups() {
  const container = $('#mediaGroups');
  container.innerHTML = '';

  for (const section of getVisibleSections()) {
    const sectionEl = createSection(section);
    container.appendChild(sectionEl);
  }
}

function getVisibleSections() {
  return MODE_TABS.filter(tab => tab.key === currentMediaMode);
}

function renderModeTabs() {
  const tabs = $('#modeTabs');
  tabs.innerHTML = '';

  MODE_TABS.forEach(tab => {
    const button = document.createElement('button');
    button.type = 'button';
    button.className = `mode-tab${currentMediaMode === tab.key ? ' active' : ''}`;
    button.textContent = tab.label;
    button.addEventListener('click', () => {
      currentMediaMode = tab.key;
      renderModeTabs();
      renderGroups();
    });
    tabs.appendChild(button);
  });
}

function createSection(section) {
  const wrapper = document.createElement('section');
  wrapper.className = 'media-section';
  wrapper.dataset.section = section.key;

  const title = document.createElement('div');
  title.className = 'section-title';

  const label = document.createElement('span');
  label.textContent = section.label;

  const count = document.createElement('span');
  count.className = 'section-count';
  count.textContent = `${getSectionItems(section).length} 项`;

  title.append(label, count);
  wrapper.appendChild(title);

  if (section.note) {
    const note = document.createElement('p');
    note.className = 'section-note';
    note.textContent = section.note;
    wrapper.appendChild(note);
  }

  section.groupKeys.forEach(groupKey => {
    const group = GROUPS.find(item => item.key === groupKey);
    if (!group) return;
    const items = allMedia[group.key] || [];
    wrapper.appendChild(createGroup(group, items));
  });

  return wrapper;
}

function getSectionItems(section) {
  return section.groupKeys.flatMap(groupKey => allMedia[groupKey] || []);
}

function createGroup(group, items) {
  const section = document.createElement('section');
  section.className = 'media-group';
  section.dataset.group = group.key;
  if (collapsedGroups.has(group.key)) {
    section.classList.add('collapsed');
  }

  const header = document.createElement('button');
  header.className = 'group-header';
  header.type = 'button';
  header.addEventListener('click', () => toggleGroup(group.key));

  const left = document.createElement('span');
  left.className = 'group-title-wrap';

  const arrow = document.createElement('span');
  arrow.className = 'group-arrow';
  arrow.textContent = '⌄';

  const titleBlock = document.createElement('span');
  titleBlock.className = 'group-title-block';

  const title = document.createElement('span');
  title.className = 'group-title';
  title.textContent = group.label;

  const hint = document.createElement('span');
  hint.className = 'group-hint';
  hint.textContent = group.hint;

  titleBlock.append(title, hint);
  left.append(arrow, titleBlock);

  const count = document.createElement('span');
  count.className = 'group-count';
  count.textContent = `${items.length} 项`;

  header.append(left, count);

  const tools = document.createElement('div');
  tools.className = 'group-tools';

  const downloadBtn = document.createElement('button');
  downloadBtn.className = 'btn btn-sm btn-secondary';
  downloadBtn.type = 'button';
  downloadBtn.textContent = '下载本组';
  downloadBtn.disabled = items.length === 0;
  downloadBtn.addEventListener('click', () => downloadGroup(group.key));

  tools.append(downloadBtn);

  const grid = document.createElement('div');
  grid.className = 'media-grid';
  renderGrid(grid, items, group.key);

  section.append(header, tools, grid);
  return section;
}

function toggleGroup(groupKey) {
  if (collapsedGroups.has(groupKey)) {
    collapsedGroups.delete(groupKey);
  } else {
    collapsedGroups.add(groupKey);
  }
  renderGroups();
  updateSelectedCards();
}

function renderGrid(grid, items, groupKey) {
  grid.innerHTML = '';

  if (items.length === 0) {
    const empty = document.createElement('div');
    empty.className = 'empty-state';
    empty.style.gridColumn = '1 / -1';

    const icon = document.createElement('div');
    icon.className = 'empty-icon';
    icon.textContent = '📭';

    const text = document.createElement('p');
    text.className = 'empty-text';
    text.textContent = '该分类下没有文件';

    empty.append(icon, text);
    grid.appendChild(empty);
    return;
  }

  items.forEach((item, index) => {
    const cat = groupKey;
    const card = document.createElement('div');
    card.className = `media-card${isVideoGroup(cat) ? ' video-card' : ''}`;
    card.dataset.group = groupKey;
    card.dataset.index = String(index);

    if (isVideoGroup(cat)) {
      renderVideoCard(card, item);
    } else {
      renderImageCard(card, item, cat);
    }

    card.addEventListener('click', (e) => {
      const key = getSelectionKey(groupKey, index);
      if (e.ctrlKey || e.metaKey) {
        e.preventDefault();
        toggleItemSelection(key);
      } else if (selectedItems.size > 0) {
        e.preventDefault();
        toggleItemSelection(key);
      } else {
        openPreview(item);
      }
    });

    card.addEventListener('dblclick', (e) => {
      e.preventDefault();
      openPreview(item);
    });

    grid.appendChild(card);
  });
}

function getSelectionKey(groupKey, index) {
  return `${groupKey}:${index}`;
}

function renderVideoCard(card, item) {
  const wrapper = document.createElement('div');
  wrapper.className = 'video-thumb-wrapper';

  if (item.poster) {
    const img = document.createElement('img');
    img.alt = '视频封面';
    img.src = item.poster;
    img.loading = 'lazy';
    img.addEventListener('error', () => {
      img.remove();
      wrapper.classList.add('no-poster');
    });
    wrapper.appendChild(img);
  } else {
    wrapper.classList.add('no-poster');
  }

  const playIcon = document.createElement('div');
  playIcon.className = 'video-play-icon';
  playIcon.textContent = '▶';

  wrapper.appendChild(playIcon);
  card.append(wrapper, createCheck(), createBadge('video', '视频'));
}

function renderImageCard(card, item, cat) {
  const img = document.createElement('img');
  img.className = 'media-thumb';
  img.src = item.highResUrl || item.url;
  img.alt = item.filename || '';
  img.loading = 'lazy';
  img.addEventListener('error', () => {
    img.style.background = '#f0f2f5';
    img.style.minHeight = '100px';
  });

  card.append(img, createCheck(), createBadge(cat, getBadgeLabel(cat)));
}

function createCheck() {
  const check = document.createElement('div');
  check.className = 'media-check';
  check.textContent = '✓';
  return check;
}

function createBadge(cat, label) {
  const badge = document.createElement('div');
  badge.className = `media-badge ${cat}`;
  badge.textContent = label;
  return badge;
}

function toggleItemSelection(key) {
  if (selectedItems.has(key)) {
    selectedItems.delete(key);
  } else {
    selectedItems.add(key);
  }
  updateSelectedCards();
  updateSelectedInfo();
}

function toggleSelectAll() {
  const checked = $('#checkAll').checked;

  if (checked) {
    GROUPS.forEach(group => {
      (allMedia[group.key] || []).forEach((_, index) => {
        selectedItems.add(getSelectionKey(group.key, index));
      });
    });
  } else {
    selectedItems.clear();
  }

  updateSelectedCards();
  updateSelectedInfo();
}

function updateSelectedCards() {
  const cards = $$('.media-card');
  cards.forEach((card) => {
    const key = getSelectionKey(card.dataset.group, card.dataset.index);
    card.classList.toggle('selected', selectedItems.has(key));
  });
}

function updateSelectedInfo() {
  const count = selectedItems.size;
  $('#selectedInfo').textContent = `已选 ${count} 项`;
  $('#btnDownloadSelected').disabled = count === 0;

  const total = getAllItems().length;
  $('#checkAll').checked = total > 0 && count === total;
  $('#checkAll').indeterminate = count > 0 && count < total;
}

function getBadgeLabel(cat) {
  const map = {
    main: '主图/卖点图',
    sku: '选购图',
    detail: '详情图',
    traffic: '直通车图',
    review: '评价图',
    video: '视频',
    reviewVideo: '评价视频'
  };
  return map[cat] || cat;
}

async function downloadSelected() {
  if (selectedItems.size === 0) return;

  const toDownload = [];

  for (const key of selectedItems) {
    const [groupKey, rawIndex] = key.split(':');
    const index = parseInt(rawIndex, 10);
    const item = allMedia[groupKey] && allMedia[groupKey][index];
    if (item) {
      toDownload.push({ item, groupKey });
    }
  }

  await downloadItems(toDownload, '选中的文件');
}

async function downloadAll() {
  await downloadItems(getAllItems(), '全部文件');
}

async function downloadGroup(groupKey) {
  const group = GROUPS.find(item => item.key === groupKey);
  const items = (allMedia[groupKey] || []).map(item => ({ item, groupKey }));
  await downloadItems(items, group ? group.label : '本组文件');
}

function getAllItems() {
  return GROUPS.flatMap(group => (allMedia[group.key] || []).map(item => ({
    item,
    groupKey: group.key
  })));
}

async function downloadItems(entries, label) {
  if (!entries.length) {
    showToast('没有可下载的文件', 'info');
    return;
  }

  showToast(`正在下载${label}，共 ${entries.length} 个...`, 'info');

  let success = 0;
  let fail = 0;

  for (const entry of entries) {
    try {
      const downloadUrl = entry.item.highResUrl || entry.item.url;
      const resp = await sendMessage('DOWNLOAD', {
        url: downloadUrl,
        filename: buildDownloadFilename(entry.item, entry.groupKey)
      });
      if (resp.success) {
        success++;
      } else {
        fail++;
      }
    } catch (err) {
      fail++;
    }

    if (entries.length > 3) {
      await sleep(250);
    }
  }

  if (fail === 0) {
    showToast(`✅ 已开始下载 ${success} 个文件`, 'success');
  } else {
    showToast(`下载完成: ${success} 成功, ${fail} 失败`, 'error');
  }
}

function buildDownloadFilename(item, groupKey) {
  const group = GROUPS.find(entry => entry.key === groupKey);
  const groupName = group ? group.label : '媒体';
  const filename = item.filename || 'media_file';
  return `${groupName}/${filename}`;
}

let previewItem = null;

function openPreview(item) {
  previewItem = item;
  const cat = getMediaCategory(item);
  const overlay = $('#previewOverlay');
  const img = $('#previewImg');
  const video = $('#previewVideo');
  const info = $('#previewInfo');

  if (isVideoGroup(cat)) {
    img.style.display = 'none';
    video.style.display = 'block';
    video.src = item.url;
    video.setAttribute('poster', item.poster || '');
    info.textContent = item.filename || item.url;
  } else {
    video.style.display = 'none';
    img.style.display = 'block';
    img.src = item.highResUrl || item.url;
    info.textContent = item.filename || item.url;
  }

  overlay.style.display = 'flex';
}

function isVideoGroup(cat) {
  return cat === 'video' || cat === 'reviewVideo';
}

function closePreview() {
  const overlay = $('#previewOverlay');
  overlay.style.display = 'none';
  $('#previewVideo').pause();
  $('#previewVideo').src = '';
  previewItem = null;
}

async function downloadPreview() {
  if (!previewItem) return;

  try {
    const downloadUrl = previewItem.highResUrl || previewItem.url;
    const resp = await sendMessage('DOWNLOAD', {
      url: downloadUrl,
      filename: previewItem.filename || 'media_file'
    });
    if (resp.success) {
      showToast('✅ 下载已开始', 'success');
    } else {
      showToast('下载失败: ' + (resp.error || '未知错误'), 'error');
    }
  } catch (err) {
    showToast('下载失败: ' + err.message, 'error');
  }
}

async function sendMessage(type, payload = {}) {
  return new Promise((resolve) => {
    chrome.runtime.sendMessage({ type, payload }, (response) => {
      if (chrome.runtime.lastError) {
        resolve({ success: false, error: chrome.runtime.lastError.message });
      } else {
        resolve(response);
      }
    });
  });
}

function showToast(msg, type) {
  const toast = $('#toast');
  const toastMsg = $('#toastMsg');
  toastMsg.textContent = msg;
  toast.className = `toast ${type}`;
  toast.style.display = 'block';
  clearTimeout(toast._timeout);
  toast._timeout = setTimeout(() => {
    toast.style.display = 'none';
  }, 3000);
}

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}
