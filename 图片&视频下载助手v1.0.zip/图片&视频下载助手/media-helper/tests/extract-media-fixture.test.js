const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const test = require('node:test');
const vm = require('node:vm');

class Element {
  constructor(tagName, attrs = {}, children = [], text = '') {
    this.tagName = tagName.toUpperCase();
    this.attrs = Object.fromEntries(
      Object.entries(attrs).map(([key, value]) => [key.toLowerCase(), String(value)])
    );
    this.children = [];
    this.parentElement = null;
    this.text = text;
    this.naturalWidth = Number(attrs.naturalWidth || attrs.width || 0);
    this.naturalHeight = Number(attrs.naturalHeight || attrs.height || 0);
    this.width = Number(attrs.width || 0);
    this.height = Number(attrs.height || 0);
    this.rect = attrs.rect || null;
    children.forEach(child => this.appendChild(child));
  }

  appendChild(child) {
    child.parentElement = this;
    this.children.push(child);
  }

  get id() {
    return this.attrs.id || '';
  }

  get className() {
    return this.attrs.class || '';
  }

  get textContent() {
    return this.text + this.children.map(child => child.textContent).join('');
  }

  get attributes() {
    return Object.entries(this.attrs).map(([name, value]) => ({ name, value }));
  }

  getAttribute(name) {
    return this.attrs[String(name).toLowerCase()] || null;
  }

  matches(selector) {
    return matchesSelector(this, selector);
  }

  closest(selector) {
    for (let node = this; node; node = node.parentElement) {
      if (matchesSelector(node, selector)) return node;
    }
    return null;
  }

  querySelectorAll(selector) {
    return querySelectorAll(this, selector);
  }

  querySelector(selector) {
    return this.querySelectorAll(selector)[0] || null;
  }

  getBoundingClientRect() {
    return this.rect || {
      top: 0,
      left: 0,
      width: this.width,
      height: this.height,
      right: this.width,
      bottom: this.height
    };
  }
}

function el(tagName, attrs = {}, children = [], text = '') {
  return new Element(tagName, attrs, children, text);
}

function img(src, attrs = {}) {
  return el('img', { src, ...attrs });
}

function splitSelectorList(selector) {
  const parts = [];
  let current = '';
  let bracketDepth = 0;

  for (const char of selector) {
    if (char === '[') bracketDepth++;
    if (char === ']') bracketDepth--;
    if (char === ',' && bracketDepth === 0) {
      parts.push(current.trim());
      current = '';
    } else {
      current += char;
    }
  }

  if (current.trim()) parts.push(current.trim());
  return parts;
}

function matchesSelector(element, selector) {
  return splitSelectorList(selector).some(part => matchesCompoundSelector(element, part));
}

function matchesCompoundSelector(element, selector) {
  const tokens = selector.split(/\s+/).filter(Boolean);
  if (tokens.length > 1) {
    if (!matchesCompoundSelector(element, tokens[tokens.length - 1])) return false;

    let ancestor = element.parentElement;
    for (let index = tokens.length - 2; index >= 0; index--) {
      while (ancestor && !matchesCompoundSelector(ancestor, tokens[index])) {
        ancestor = ancestor.parentElement;
      }
      if (!ancestor) return false;
      ancestor = ancestor.parentElement;
    }
    return true;
  }

  const tagName = selector.match(/^[a-zA-Z][\w-]*/)?.[0];
  if (tagName && element.tagName.toLowerCase() !== tagName.toLowerCase()) return false;

  for (const id of selector.matchAll(/#([\w-]+)/g)) {
    if (element.id !== id[1]) return false;
  }

  for (const className of selector.matchAll(/\.([\w-]+)/g)) {
    if (!element.className.split(/\s+/).includes(className[1])) return false;
  }

  for (const attr of selector.matchAll(/\[([^\]=*]+)(\*?=)?"?([^\]"]*)"?\]/g)) {
    const value = element.getAttribute(attr[1]) || '';
    if (!attr[2]) {
      if (!element.getAttribute(attr[1])) return false;
    } else if (attr[2] === '*=') {
      if (!value.includes(attr[3])) return false;
    } else if (value !== attr[3]) {
      return false;
    }
  }

  return true;
}

function querySelectorAll(scope, selector) {
  const descendants = [];

  function walk(node) {
    node.children.forEach(child => {
      descendants.push(child);
      walk(child);
    });
  }

  walk(scope);
  return descendants.filter(element => matchesSelector(element, selector));
}

function createFixtureDocument() {
  const root = el('html', {}, [
    el('head', {}, [
      el('meta', {
        property: 'og:image',
        content: 'https://img.alicdn.com/imgextra/i1/O1CN-main-og.jpg_400x400.jpg'
      }),
      el('script', {}, [], `
        window.__DATA__ = {
          auctionImages: ["//img.alicdn.com/imgextra/i1/O1CN-main-script.jpg_800x800.jpg"],
          sku: { propImg: "//img.alicdn.com/imgextra/i2/O1CN-sku-script.jpg_60x60.jpg" },
          apiItemDesc: "//img.alicdn.com/imgextra/i3/O1CN-detail-script.jpg",
          review: { imageUrl: "//img.alicdn.com/imgextra/i4/O1CN-review-script.jpg" },
          traffic: { creative: "//img.alicdn.com/imgextra/i5/O1CN-ztc-script.jpg" },
          vehicle: { carModel: "//img.alicdn.com/imgextra/i5/O1CN-vehicle-script.jpg" },
          videoUrl: "https://cloud.video.taobao.com/play/u/1/p/1/e/6/t/1/123.mp4",
          logo: "//img.alicdn.com/tfs/TB1-shop-logo.png",
          serviceIcon: "//img.alicdn.com/imgextra/i6/O1CN-service-promise.jpg"
        };
      `)
    ]),
    el('body', {}, [
      el('div', { class: 'shop header' }, [
        img('https://img.alicdn.com/imgextra/logo/shop-logo.png', { width: 220, height: 80 }),
        img('https://img.alicdn.com/tfs/icon/cart-icon.png', { width: 32, height: 32 })
      ]),
      el('div', { class: 'gallery mainpic' }, [
        img('https://img.alicdn.com/imgextra/i1/O1CN-main1.jpg_430x430.jpg', { width: 430, height: 430 }),
        el('div', {
          class: 'main-thumb',
          style: 'background-image:url("//img.alicdn.com/imgextra/i1/O1CN-main-bg.jpg_430x430.jpg")'
        }),
        img('https://img.alicdn.com/imgextra/i1/O1CN-sku-in-gallery.jpg_430x430.jpg', {
          class: 'sku-image',
          width: 430,
          height: 430
        })
      ]),
      el('ul', { id: 'J_TSaleProp', class: 'sku-wrap' }, [
        img('https://img.alicdn.com/imgextra/i2/O1CN-sku-red.jpg_60x60.jpg', { width: 60, height: 60 }),
        img('https://img.alicdn.com/imgextra/i2/O1CN-sku-blue.jpg_60x60.jpg', { width: 60, height: 60 }),
        el('li', {
          class: 'sku-item',
          style: 'background-image:url("//img.alicdn.com/imgextra/i2/O1CN-sku-bg.jpg_60x60.jpg")'
        }),
        img('https://img.alicdn.com/tfs/icon/sku-check-icon.png', { width: 48, height: 48 })
      ]),
      el('div', { class: 'sellpoint feature' }, [
        img('https://img.alicdn.com/imgextra/i3/O1CN-selling.jpg', { width: 750, height: 500 })
      ]),
      el('div', { class: 'ztc creative' }, [
        img('https://img.alicdn.com/imgextra/i5/O1CN-ztc1.jpg', { width: 800, height: 800 })
      ]),
      el('div', { id: 'J_DivItemDesc', class: 'detail-content' }, [
        img('https://img.alicdn.com/imgextra/i3/O1CN-detail1.jpg', { width: 750, height: 900 }),
        el('div', { class: 'swiper detail-gallery' }, [
          img('https://img.alicdn.com/imgextra/i3/O1CN-detail-swiper-long.jpg', { width: 750, height: 1200 })
        ]),
        el('div', { class: 'promotion detail-promo' }, [
          img('https://img.alicdn.com/imgextra/i3/O1CN-detail-promo-long.jpg', { width: 750, height: 1100 })
        ]),
        el('div', { class: 'sku nested' }, [
          img('https://img.alicdn.com/imgextra/i2/O1CN-sku-nested.jpg_60x60.jpg', {
            width: 60,
            height: 60
          })
        ]),
        el('div', { class: 'vehicle carmodel 车型' }, [
          img('https://img.alicdn.com/imgextra/i5/O1CN-vehicle1.jpg', {
            width: 750,
            height: 360
          })
        ])
      ]),
      el('div', { id: 'J_Rate', class: 'review comment' }, [
        img('https://img.alicdn.com/imgextra/i4/O1CN-review1.jpg', { width: 460, height: 460 }),
        el('div', { class: 'gallery swiper' }, [
          img('https://img.alicdn.com/imgextra/i4/O1CN-review-swiper.jpg', { width: 460, height: 460 })
        ]),
        img('https://img.alicdn.com/imgextra/i4/O1CN-blank.png_1x1.png', {
          class: 'placeholder',
          width: 1,
          height: 1
        }),
        el('div', { 'data-video-url': 'https://cloud.video.taobao.com/review/rv.mp4' })
      ]),
      el('div', {
        class: 'main-video',
        'data-video-url': 'https://cloud.video.taobao.com/main/product-data.mp4',
        'data-poster': 'https://img.alicdn.com/imgextra/i1/O1CN-data-poster.jpg'
      }),
      el('div', {
        class: 'main-video duplicate-video',
        'data-video-url': 'https://cloud.video.taobao.com/main/product-data.mp4',
        'data-poster': 'https://img.alicdn.com/imgextra/i1/O1CN-data-poster.jpg'
      }),
      el('video', {
        src: 'https://cloud.video.taobao.com/main/product.mp4',
        poster: 'https://img.alicdn.com/imgextra/i1/O1CN-poster.jpg'
      }, [
        el('source', { src: 'https://cloud.video.taobao.com/main/product-source.mp4' })
      ])
    ])
  ]);

  const nodes = [];
  (function walk(node) {
    nodes.push(node);
    node.children.forEach(walk);
  })(root);

  return {
    querySelectorAll(selector) {
      return nodes.filter(node => matchesSelector(node, selector));
    },
    querySelector(selector) {
      return this.querySelectorAll(selector)[0] || null;
    },
    title: 'fixture product'
  };
}

function extractFixtureMedia() {
  const document = createFixtureDocument();
  const context = {
    document,
    window: {
      location: {
        href: 'https://detail.tmall.com/item.htm?id=1',
        hostname: 'detail.tmall.com'
      },
      innerWidth: 1440,
      innerHeight: 900,
      scrollY: 0,
      pageYOffset: 0
    },
    globalThis: null,
    URL
  };
  context.globalThis = context;
  context.window.window = context.window;
  context.window.document = document;

  const code = fs.readFileSync(path.join(__dirname, '..', 'content', 'content.js'), 'utf8');
  vm.runInNewContext(code, context);
  return context.__mediaHelperExtractMedia();
}

function createModernTmallDocument() {
  const root = el('html', {}, [
    el('head', {}, [
      el('meta', {
        property: 'og:image',
        content: 'https://img.alicdn.com/imgextra/i1/O1CN-modern-og.jpg_400x400.jpg'
      }),
      el('script', {}, [], `
        window.__MODERN__ = {
          auctionImages: ["//img.alicdn.com/imgextra/i1/O1CN-modern-main-script.jpg_800x800.jpg"],
          skuBase: {
            list: [
              { imageUrl: "//img.alicdn.com/imgextra/i2/O1CN-modern-sku-1.jpg_430x430.jpg" },
              { imageUrl: "//img.alicdn.com/imgextra/i2/O1CN-modern-sku-2.jpg_430x430.jpg" }
            ]
          },
          detail: { imageUrl: "//img.alicdn.com/imgextra/i3/O1CN-modern-detail-script.jpg" },
          reviewFeeds: [
            { imageUrl: "//img.alicdn.com/imgextra/i4/O1CN-modern-review-script.jpg", videoUrl: "https://cloud.video.taobao.com/review/modern-review.mp4", cover: "//img.alicdn.com/imgextra/i4/O1CN-modern-review-cover.jpg" }
          ],
          productVideo: { videoUrl: "https://cloud.video.taobao.com/main/modern-product.mp4", cover: "//img.alicdn.com/imgextra/i1/O1CN-modern-product-cover.jpg" }
        };
      `)
    ]),
    el('body', {}, [
      el('main', { class: 'item-page' }, [
        el('section', { class: 'left media column' }, [
          img('https://img.alicdn.com/imgextra/i1/O1CN-modern-main-hero.jpg_790x790.jpg', {
            width: 790,
            height: 790,
            rect: { top: 150, left: 260, width: 520, height: 520, right: 780, bottom: 670 }
          }),
          img('https://img.alicdn.com/imgextra/i1/O1CN-modern-main-sellpoint.jpg_790x790.jpg', {
            class: 'feature-card',
            width: 90,
            height: 90,
            rect: { top: 250, left: 50, width: 70, height: 70, right: 120, bottom: 320 }
          })
        ], '视频 图集 参数'),
        el('section', { class: 'purchase panel' }, [
          el('div', { class: 'color-classify' }, [
            img('https://img.alicdn.com/imgextra/i2/O1CN-modern-sku-dom.jpg_120x120.jpg', {
              width: 64,
              height: 64,
              rect: { top: 540, left: 860, width: 64, height: 64, right: 924, bottom: 604 }
            })
          ], '颜色分类')
        ]),
        el('section', { class: 'tab content-area' }, [
          el('div', { class: 'modern-detail-block swiper promotion' }, [
            img('https://img.alicdn.com/imgextra/i3/O1CN-modern-detail-sellpoint.jpg', {
              width: 790,
              height: 790,
              rect: { top: 980, left: 250, width: 790, height: 790, right: 1040, bottom: 1770 }
            })
          ])
        ], '图文详情'),
        el('section', { class: 'ugc area' }, [
          el('div', { class: 'gallery swiper sku-text-wrapper' }, [
            img('https://img.alicdn.com/imgextra/i4/O1CN-modern-review-photo.jpg', {
              width: 460,
              height: 460,
              rect: { top: 1880, left: 80, width: 220, height: 220, right: 300, bottom: 2100 }
            }),
            el('div', {
              class: 'video-box',
              'data-video-url': 'https://cloud.video.taobao.com/review/modern-dom-review.mp4',
              'data-cover': 'https://img.alicdn.com/imgextra/i4/O1CN-modern-dom-review-cover.jpg'
            })
          ], '颜色规格 买家秀')
        ], '用户评价 · 14'),
        el('section', { class: 'right rail creative-list' }, [
          img('https://img.alicdn.com/imgextra/i5/O1CN-modern-traffic.jpg', {
            width: 800,
            height: 800,
            rect: { top: 1400, left: 1220, width: 160, height: 160, right: 1380, bottom: 1560 }
          })
        ], '直通车图')
      ])
    ])
  ]);

  const nodes = [];
  (function walk(node) {
    nodes.push(node);
    node.children.forEach(walk);
  })(root);

  return {
    documentElement: { clientWidth: 1440 },
    querySelectorAll(selector) {
      return nodes.filter(node => matchesSelector(node, selector));
    },
    querySelector(selector) {
      return this.querySelectorAll(selector)[0] || null;
    },
    title: 'modern fixture product'
  };
}

function extractModernTmallMedia() {
  const document = createModernTmallDocument();
  const context = {
    document,
    window: {
      location: {
        href: 'https://detail.tmall.com/item.htm?id=2',
        hostname: 'detail.tmall.com'
      },
      innerWidth: 1440,
      innerHeight: 900,
      scrollY: 0,
      pageYOffset: 0
    },
    globalThis: null,
    URL
  };
  context.globalThis = context;
  context.window.window = context.window;
  context.window.document = document;

  const code = fs.readFileSync(path.join(__dirname, '..', 'content', 'content.js'), 'utf8');
  vm.runInNewContext(code, context);
  return context.__mediaHelperExtractMedia();
}

function urls(result, category) {
  return result[category].map(item => item.url);
}

test('classifies product media without mixing sku, detail, review, and video groups', () => {
  const result = extractFixtureMedia();
  const main = urls(result, 'main');
  const sku = urls(result, 'sku');
  const detail = urls(result, 'detail');
  const traffic = urls(result, 'traffic');
  const review = urls(result, 'review');
  const video = urls(result, 'video');
  const reviewVideo = urls(result, 'reviewVideo');

  assert(main.some(url => url.includes('O1CN-main1')));
  assert(main.some(url => url.includes('O1CN-main-bg')));
  assert(main.some(url => url.includes('O1CN-selling')));
  assert(main.some(url => url.includes('main-script')));
  assert(!main.some(url => /sku-red|sku-blue|shop-logo|cart-icon|service-promise|review-swiper|review-script|detail-swiper|detail-promo/.test(url)));

  assert(sku.some(url => url.includes('sku-red')));
  assert(sku.some(url => url.includes('sku-blue')));
  assert(sku.some(url => url.includes('sku-bg')));
  assert(sku.some(url => url.includes('sku-script')));
  assert(sku.some(url => url.includes('sku-in-gallery')));
  assert(!sku.some(url => /sku-check-icon/.test(url)));

  assert(detail.some(url => url.includes('detail1')));
  assert(detail.some(url => url.includes('detail-swiper-long')));
  assert(detail.some(url => url.includes('detail-promo-long')));
  assert(detail.some(url => url.includes('detail-script')));
  assert(detail.some(url => url.includes('vehicle1')));
  assert(!detail.some(url => url.includes('sku-nested')));

  assert(traffic.some(url => url.includes('ztc1')));
  assert(traffic.some(url => url.includes('ztc-script')));
  assert(!traffic.some(url => /vehicle|detail-promo/.test(url)));

  assert(review.some(url => url.includes('review1')));
  assert(review.some(url => url.includes('review-swiper')));
  assert(review.some(url => url.includes('review-script')));
  assert(!review.some(url => url.includes('blank')));

  assert(video.some(url => url.includes('product.mp4')));
  assert(video.some(url => url.includes('/123.mp4')));
  assert.equal(video.filter(url => url.includes('product-data.mp4')).length, 1);
  assert(result.video.some(item => item.url.includes('product-data.mp4') && item.poster.includes('O1CN-data-poster')));
  assert(reviewVideo.some(url => url.includes('/review/rv.mp4')));
});

test('keeps modern Tmall main, sku, detail, traffic, review, and review videos separated', () => {
  const result = extractModernTmallMedia();
  const main = urls(result, 'main');
  const sku = urls(result, 'sku');
  const detail = urls(result, 'detail');
  const traffic = urls(result, 'traffic');
  const review = urls(result, 'review');
  const video = urls(result, 'video');
  const reviewVideo = urls(result, 'reviewVideo');

  assert(main.some(url => url.includes('modern-main-hero')));
  assert(main.some(url => url.includes('modern-main-sellpoint')));
  assert(!main.some(url => /modern-review-photo|modern-detail-sellpoint|modern-traffic|modern-sku-dom/.test(url)));

  assert(sku.some(url => url.includes('modern-sku-dom')));
  assert(!sku.some(url => /modern-review-photo|modern-main/.test(url)));

  assert(detail.some(url => url.includes('modern-detail-sellpoint')));
  assert(!detail.some(url => /modern-main|modern-review-photo/.test(url)));

  assert(traffic.some(url => url.includes('modern-traffic')));
  assert(!traffic.some(url => /modern-review-photo|modern-detail-sellpoint/.test(url)));

  assert(review.some(url => url.includes('modern-review-photo')));
  assert(!review.some(url => /modern-sku-dom|modern-main/.test(url)));

  assert(video.some(url => url.includes('modern-product.mp4')));
  assert(result.video.some(item => item.url.includes('modern-product.mp4') && item.poster.includes('modern-product-cover')));
  assert(reviewVideo.some(url => url.includes('modern-review.mp4')));
  assert(reviewVideo.some(url => url.includes('modern-dom-review.mp4')));
  assert(result.reviewVideo.every(item => item.poster));
  assert(!video.some(url => url.includes('modern-review')));
});
